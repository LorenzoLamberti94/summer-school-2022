"""
Various types of TSP utilizing local planners for distance estimation and path planning
@author: P. Petracek & V. Kratky & P.Vana & P.Cizek & R.Penicka
"""

import numpy as np

from random import randint

from sklearn.cluster import KMeans
from scipy.spatial.kdtree import KDTree

from utils import *
from path_planners.grid_based.grid_3d import Grid3D
from path_planners.grid_based.astar   import AStar
from path_planners.sampling_based.rrt import RRT

from solvers.LKHInvoker import LKHInvoker



class TSPSolver3D():

    ALLOWED_PATH_PLANNERS               = ('euclidean', 'astar', 'rrt', 'rrtstar')
    ALLOWED_DISTANCE_ESTIMATION_METHODS = ('euclidean', 'astar', 'rrt', 'rrtstar')
    GRID_PLANNERS                       = ('astar')

    def __init__(self):
        self.lkh = LKHInvoker()
        self.computed_path = {}

    # # #{ setup()
    def setup(self, problem, path_planner, viewpoints):
        """setup objects required in path planning methods"""

        if path_planner is None:
            return

        assert path_planner['path_planning_method'] in self.ALLOWED_PATH_PLANNERS, 'Given method to compute path (%s) is not allowed. Allowed methods: %s' % (path_planner, self.ALLOWED_PATH_PLANNERS)
        assert path_planner['distance_estimation_method'] in self.ALLOWED_DISTANCE_ESTIMATION_METHODS, 'Given method for distance estimation (%s) is not allowed. Allowed methods: %s' % (path_planner, self.ALLOWED_DISTANCE_ESTIMATION_METHODS)

        # Setup environment
        if path_planner['path_planning_method'] != 'euclidean' or path_planner['distance_estimation_method'] != 'euclidean':

            # setup KD tree for collision queries
            obstacles_array = np.array([[opt.x, opt.y, opt.z] for opt in problem.obstacle_points])
            path_planner['obstacles_kdtree'] = KDTree(obstacles_array)

            # setup environment bounds
            xs = [p.x for p in problem.safety_area]
            ys = [p.y for p in problem.safety_area]
            x_min, x_max = min(xs), max(xs)
            y_min, y_max = min(ys), max(ys)
            path_planner['bounds'] = Bounds(Point(x_min, y_min, problem.min_height), Point(x_max, y_max, problem.max_height))

        # Setup 3D grid for grid-based planners
        if path_planner['path_planning_method'] in self.GRID_PLANNERS or path_planner['distance_estimation_method'] in self.GRID_PLANNERS:

            # construct grid
            x_list = [opt.x for opt in problem.obstacle_points]
            x_list.extend([tar.pose.point.x for tar in viewpoints])
            y_list = [opt.y for opt in problem.obstacle_points]
            y_list.extend([tar.pose.point.y for tar in viewpoints])
            z_list = [opt.z for opt in problem.obstacle_points]
            z_list.extend([tar.pose.point.z for tar in viewpoints])
            min_x = np.min(x_list)
            max_x = np.max(x_list)
            min_y = np.min(y_list)
            max_y = np.max(y_list)
            min_z = np.min(z_list)
            max_z = np.max(z_list)

            dim_x = int(np.ceil((max_x - min_x) / path_planner['astar/grid_resolution']))+1
            dim_y = int(np.ceil((max_y - min_y) / path_planner['astar/grid_resolution']))+1
            dim_z = int(np.ceil((max_z - min_z) / path_planner['astar/grid_resolution']))+1

            path_planner['grid'] = Grid3D(idx_zero = (min_x, min_y,min_z), dimensions=(dim_x,dim_y,dim_z), resolution_xyz=path_planner['astar/grid_resolution'])
            path_planner['grid'].setObstacles(problem.obstacle_points, path_planner['safety_distance'])

    # # #}

    # #{ plan_tour()

    def plan_tour(self, problem, viewpoints, path_planner=None):
        '''
        Solve TSP on viewpoints with given goals and starts

        Parameters:
            problem (InspectionProblem): task problem
            viewpoints (list[Viewpoint]): list of Viewpoint objects
            path_planner (dict): dictionary of parameters

        Returns:
            path (list): sequence of points with start equaling the end
        '''

        # Setup 3D grid for grid-based planners and KDtree for sampling-based planners
        self.setup(problem, path_planner, viewpoints)

        n              = len(viewpoints)
        self.distances = np.zeros((n, n))
        self.paths = {}

        # find path between each pair of goals (a, b)
        for a in range(n):
            for b in range(n):
                if a == b:
                    continue

                # [STUDENTS TODO]
                #   - Play with distance estimates in TSP (tsp/distance_estimates parameter in config) and see how it influences the solution
                #   - You will probably see that computing for all poses from both sets takes a long time.
                #   - Think if you can limit the number of computations or decide which distance-estimating method use for each point-pair.

                # get poses of the viewpoints
                g1 = viewpoints[a].pose
                g2 = viewpoints[b].pose

                # estimate distances between the viewpoints
                path, distance = self.compute_path(g1, g2, path_planner, path_planner['distance_estimation_method'])

                # store paths/distances in matrices
                self.paths[(a, b)]   = path
                self.distances[a][b] = distance

        # compute TSP tour
        path = self.compute_tsp_tour(viewpoints, path_planner)

        return path

    # #}

    # # #{ compute_path()

    def compute_path(self, p_from, p_to, path_planner, path_planner_method):
        '''
        Computes collision-free path (if feasible) between two points

        Parameters:
            p_from (Pose): start
            p_to (Pose): to
            path_planner (dict): dictionary of parameters
            path_planner_method (string): method of path planning

        Returns:
            path (list[Pose]): sequence of points
            distance (float): length of path
        '''
        if path_planner_method not in self.computed_path.keys():
            self.computed_path[path_planner_method] = {}

        if (p_from.point.asTuple(), p_to.point.asTuple()) in self.computed_path.keys():
            return self.computed_path[path_planner_method][(p_from.point.asTuple(), p_to.point.asTuple())]

        path, distance = [], float('inf')

        # Use Euclidean metric
        if path_planner is None or path_planner_method == 'euclidean':

            path, distance = [p_from, p_to], distEuclidean(p_from, p_to)

        # Plan with A*
        elif path_planner_method == 'astar':

            astar = AStar(path_planner['grid'], path_planner['safety_distance'], path_planner['timeout'], path_planner['straighten'])
            path, distance = astar.generatePath(p_from.asList(), p_to.asList())
            if path:
                path = [Pose(p[0], p[1], p[2], p[3]) for p in path]

        # Plan with RRT/RRT*
        elif path_planner_method.startswith('rrt'):

            rrt = RRT()
            path, distance = rrt.generatePath(p_from.asList(), p_to.asList(), path_planner, rrtstar=(path_planner_method == 'rrtstar'), straighten=path_planner['straighten'])
            if path:
                path = [Pose(p[0], p[1], p[2], p[3]) for p in path]

        if path is None or len(path) == 0:
            rospy.logerr('No path found. Shutting down.')
            rospy.signal_shutdown('No path found. Shutting down.');
            exit(-2)

        # store computed path
        self.computed_path[path_planner_method][(p_from.point.asTuple(), p_to.point.asTuple())] = (path, distance)

        return path, distance

    # # #}

    # #{ compute_tsp_tour()

    def compute_tsp_tour(self, viewpoints, path_planner):
        '''
        Compute the shortest tour based on the distance matrix (self.distances) and connect the path throught waypoints

        Parameters:
            viewpoints (list[Viewpoint]): list of VPs
            path_planner (dict): dictionary of parameters

        Returns:
            path (list[Poses]): sequence of points with start equaling the end
        '''

        # compute the shortest sequence given the distance matrix
        sequence = self.compute_tsp_sequence()

        path = []
        n    = len(self.distances)

        for a in range(n):
            b = (a + 1) % n
            a_idx       = sequence[a]
            b_idx       = sequence[b]

            # if the paths are already computed
            if path_planner['distance_estimation_method'] == path_planner['path_planning_method']:
                actual_path = self.paths[(a_idx, b_idx)]
            # if the path planning and distance estimation methods differ, we need to compute the path
            else:
                actual_path, _ = self.compute_path(viewpoints[a_idx].pose, viewpoints[b_idx].pose, path_planner, path_planner['path_planning_method'])

            # join paths
            path = path + actual_path[:-1]

            # force flight to end point
            if a == (n - 1):
                path = path + [viewpoints[b_idx].pose]

        return path

    # #}

    # # #{ compute_tsp_sequence()

    def compute_tsp_sequence(self):
        '''
        Compute the shortest sequence based on the distance matrix (self.distances) using LKH

        Returns:
            sequence (list): sequence of viewpoints ordered optimally w.r.t the distance matrix
        '''

        n = len(self.distances)

        fname_tsp = "problem"
        user_comment = "a comment by the user"
        self.lkh.writeTSPLIBfile_FE(fname_tsp, self.distances, user_comment)
        self.lkh.run_LKHsolver_cmd(fname_tsp, silent=True)
        sequence = self.lkh.read_LKHresult_cmd(fname_tsp)

        if len(sequence) > 0 and sequence[0] is not None:
            for i in range(len(sequence)):
                if sequence[i] is None:
                    new_sequence = sequence[i:len(sequence)] + sequence[:i]
                    sequence = new_sequence
                    break

        return sequence

    # # #}

    # #{ clusterViewpoints()

    def clusterViewpoints(self, problem, viewpoints, method, data=None):
        '''
        Clusters viewpoints into K (number of robots) clusters.

        Parameters:
            problem (InspectionProblem): task problem
            viewpoints (list): list of Viewpoint objects
            method (string): method ('random', 'kmeans')

        Returns:
            clusters (Kx list): clusters of points indexed for each robot:
        '''
        k = problem.number_of_robots

        ## | ------------------- K-Means clustering ------------------- |
        if method == 'kmeans':
            # Prepare positions of the viewpoints in the world
            positions = np.array([vp.pose.point.asList() for vp in viewpoints])

            # Tips:
            #  - utilize sklearn.cluster.KMeans implementation (https://scikit-learn.org/stable/modules/generated/sklearn.cluster.KMeans.html)
            #  - after finding the labels, you may want to swap the classes (e.g., by looking at the distance of the UAVs from the cluster centers)
            already_allocated_centers = data["already_allocated_centers"]
            init_centers = np.zeros(shape=(2, 3))
            init_centers[0,0] = already_allocated_centers[0][0]
            init_centers[0,1] = already_allocated_centers[0][1]
            init_centers[0,2] = already_allocated_centers[0][2]
            init_centers[1,0] = already_allocated_centers[1][0]
            init_centers[1,1] = already_allocated_centers[1][1]
            init_centers[1,2] = already_allocated_centers[1][2]

            z_diff = init_centers[0, 2] - init_centers[1, 2]
            z_factor = 1000
            init_centers[0, 2] += z_diff*z_factor
            init_centers[1, 2] -= z_diff*z_factor

            print(init_centers)
            kmeans = KMeans(k, init=init_centers).fit(positions)

            # TODO: fill 1D list 'labels' of size len(viewpoints) with indices of the robots
            # labels = [randint(0, k - 1) for vp in viewpoints]

            labels = kmeans.labels_

        elif method == "nearest":
            already_allocated_viewpoints = data["allocated_vps"]
            path_planner = data["path_planner"]
            nonclustered_vps = viewpoints
            clusters = []
            for r in range(k):
                clusters.append([])
            print("\n\nNEAREST\n\n")
            while nonclustered_vps:
                vp_to_class = nonclustered_vps.pop()
                nearest_vp = self.findNearestViewPoint(vp_to_class,
                                                       already_allocated_viewpoints[0] + already_allocated_viewpoints[1],
                                                       path_planner)
                if nearest_vp in already_allocated_viewpoints[0]:
                    clusters[0].append(vp_to_class)
                elif nearest_vp in already_allocated_viewpoints[1]:
                    clusters[1].append(vp_to_class)
                else:
                    nonclustered_vps.append(vp_to_class)

            print("\n\nEND NEAREST\n\n")
            return clusters

        ## | -------------------- Random clustering ------------------- |
        else:
            labels = [randint(0, k - 1) for vp in viewpoints]

        # Store as clusters (2D array of viewpoints)
        clusters = []
        for r in range(k):
            clusters.append([])

            for label in range(len(labels)):
                if labels[label] == r:
                    clusters[r].append(viewpoints[label])

        return clusters

    def findNearestViewPoint(self, viewpoint, viewpoint_list, path_planner, check_factor = 1.1):
        nearest = None
        closest_dist = None
        for vp in viewpoint_list:
            if path_planner['distance_estimation_method'] != "euclidean":
                path, dist = self.compute_path(viewpoint.pose, vp.pose, path_planner, "euclidean")
                if closest_dist and dist > check_factor*closest_dist:
                    # do not take time to check this vp, the euclidean distance is too great
                    continue
            path, dist = self.compute_path(viewpoint.pose, vp.pose, path_planner, path_planner['distance_estimation_method'])
            if closest_dist is None or closest_dist > dist:
                closest_dist = dist
                nearest = vp
        if nearest is None:
            return self.findNearestViewPoint(viewpoint, viewpoint_list, path_planner, check_factor=check_factor + 0.1)
        return nearest

    # #}